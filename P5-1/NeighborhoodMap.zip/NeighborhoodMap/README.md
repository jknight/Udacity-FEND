# Udacity FEND:: Project 5: Neighborhood Map

## About

This project renders a full screen map that has the following functionality:

1. A search bar
1. A list view
1. The map

## How to run it

- Unzip the .zip file 
- Double click on index.html
- Click on map markers
- Click on the vertical gray bar to show/hide list of locations

## Notes
Knockout.js uses MVVM pattern
